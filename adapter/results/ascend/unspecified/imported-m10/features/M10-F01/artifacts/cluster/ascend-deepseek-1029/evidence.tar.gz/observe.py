# SPDX-FileCopyrightText: Copyright (c) 2026 HEYI. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
import json,pathlib,subprocess,time
out=pathlib.Path('/var/tmp/dynamo-regression-1028/ascend-deepseek-1029');base=['ssh','-F','/var/tmp/dynamo-regression-1028/ssh-config','huawei-52'];start=time.monotonic()
for i in range(50):
 row={'elapsed':time.monotonic()-start,'timestamp':time.time()}
 for name,cmd in [('resources','kubectl exec -n dynamo-regression-1028 deployment/ascend-deepseek-worker-0 -- /opt/dynamo/venv/bin/python /regression/resources.py'),('job','kubectl get job -n dynamo-regression-1028 ascend-deepseek-load-30m -o json'),('pods','kubectl get pods -n dynamo-regression-1028 -l app=ascend-deepseek-worker-0 -o json')]:
  p=subprocess.run(base+[cmd],capture_output=True,text=True,timeout=45)
  try:row[name]=json.loads(p.stdout)
  except ValueError:row[name]={'error':p.stderr,'stdout':p.stdout}
 (out/f'load-snapshot-{i:03}.json').write_text(json.dumps(row))
 print(json.dumps({'sample':i,'elapsed':round(row['elapsed']), 'job':row['job'].get('status',{}),'processes':len(row['resources'].get('processes',{}))}),flush=True)
 if row['job'].get('status',{}).get('succeeded') or row['job'].get('status',{}).get('failed'):break
 time.sleep(50)
